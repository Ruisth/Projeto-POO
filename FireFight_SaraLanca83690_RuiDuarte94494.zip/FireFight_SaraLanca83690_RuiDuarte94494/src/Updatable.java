
public interface Updatable {

}
