import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Point2D;
import java.awt.event.KeyEvent;

// Esta classe de exemplo esta' definida de forma muito basica, sem relacoes de heranca
// Tem atributos e metodos repetidos em relacao ao que est� definido noutras classes 
// Isso sera' de evitar na versao a serio do projeto

public class Plane implements ImageTile, Movable{

	private Point2D position;
	

	public Plane(Point2D position) {
		this.position = position;
	}
	
	
//	//Funcao verifica fogos
//	public boolean haveFire(Point2D p) {
//		for 
//		
//	}
//	
	
	
	
	// Move numa direcao vertical onde houver mais fogos
	@Override
	public void move(int key) {
		
		boolean hasMoved = false;
		
		while (hasMoved == false)
		
		if( key == KeyEvent.VK_P) {
			Direction planeDir = Direction.directionFor(key);			   //
			Point2D planePosition = position.plus(planeDir.asVector());    //   C�DIGO PARA COLOCAR NO AVIAO
																		   //
			
			if (canMoveTo(planePosition) ) {
				setPosition(planePosition);
				hasMoved = true;
			}
		}
	}
	
	

	// Verifica se a posicao p esta' dentro da grelha de jogo
	@Override
	public boolean canMoveTo(Point2D p) {
		
		if (p.getX() < 0) return false;
		if (p.getY() < 0) return false;
		if (p.getX() >= GameEngine.GRID_WIDTH) return false;
		if (p.getY() >= GameEngine.GRID_HEIGHT) return false;
		return true;
	}
	
	public void setPosition(Point2D position) {
		this.position = position;
	}

	// Metodos de ImageTile
	@Override
	public String getName() {
		return "plane";
	}
	
	@Override
	public Point2D getPosition() {
		return position;
	}
	
	@Override
	public int getLayer() {
		return 4;
	}
}
