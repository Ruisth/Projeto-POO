import pt.iul.ista.poo.utils.Point2D;

public interface Burnable {

	// Aqui ser� implementado o modelo de propaga��o do fogo 
	// para cada objeto que pode arder
	
	
	public boolean isBurnable(Point2D p);
}
