
public interface ActiveElement {
	
	public boolean isActive();

}
