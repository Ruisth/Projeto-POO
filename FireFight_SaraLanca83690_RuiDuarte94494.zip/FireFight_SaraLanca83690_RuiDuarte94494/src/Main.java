import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		
		// Cria uma instancia de GameEngine e depois inicia o jogo
		// Podera' vir a ficar diferente caso defina GameEngine como solitao
		
				
		
//		File file = new File("example.txt");
		
		GameEngine game = GameEngine.getInstance();
		
//		try {
//			Scanner fileScanner = new Scanner(file);
		
//		
//			while(fileScanner.hasNextLine()) {
//				String line = fileScanner.nextLine();
//				System.out.println(line);
//			}
//			
//			fileScanner.close();
//		}
//		catch (FileNotFoundException e) {
//			System.err.println("Erro na abertura do ficheiro");
//		}
		
		game.start();
		
	}
}
